Sample configuration files for:
```
SystemD: bitcoinblued.service
Upstart: bitcoinblued.conf
OpenRC:  bitcoinblued.openrc
         bitcoinblued.openrcconf
CentOS:  bitcoinblued.init
macOS:    org.bitcoinblue.bitcoinblued.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
